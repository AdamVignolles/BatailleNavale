import os
os.system('python3 -m pip install socket')
os.system('python3-m pip install threading')
os.system('python3 -m pip install turtle')